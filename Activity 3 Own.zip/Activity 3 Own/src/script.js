import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import * as CANNON from 'cannon-es'

const THEMES = [
{ name: 'Neon-Rainbow', colors: [0xff00ff, 0x00fff2, 0xffea00, 0xff6ec7] },
{ name: 'Magenta-Cyan', colors: [0xff00ff, 0x00eaff, 0x9b00ff] },
{ name: 'Hot-Pink-Teal', colors: [0xff4da6, 0x00ffd5, 0xffd900] }
]
let themeIndex = 0

// HTML UI
const playBtn = document.getElementById('playBtn')
const fileInput = document.getElementById('fileInput')


// Scene setup
const container = document.getElementById('container')
const scene = new THREE.Scene()
scene.fog = new THREE.FogExp2(0x050006, 0.035)


const sizes = { width: window.innerWidth, height: window.innerHeight }


const camera = new THREE.PerspectiveCamera(60, sizes.width / sizes.height, 0.1, 1000)
camera.position.set(0, 1.6, 18)
scene.add(camera)


const renderer = new THREE.WebGLRenderer({ antialias: true })
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
renderer.setSize(sizes.width, sizes.height)
renderer.toneMappingExposure = 1
container.appendChild(renderer.domElement)

const controls = new OrbitControls(camera, renderer.domElement)
controls.enableDamping = true
controls.minDistance = 6
controls.maxDistance = 60
controls.enablePan = false
controls.autoRotate = false


// Lighting
const ambient = new THREE.HemisphereLight(0x606080, 0x000000, 0.35)
scene.add(ambient)
const rim1 = new THREE.PointLight(0xff00ff, 1.2, 60)
rim1.position.set(10, 6, 8)
scene.add(rim1)
const rim2 = new THREE.PointLight(0x00fff2, 1.2, 60)
rim2.position.set(-8, -6, -6)
scene.add(rim2)


const world = new CANNON.World()
world.gravity.set(0, -2, 0)
world.broadphase = new CANNON.NaiveBroadphase()
world.solver.iterations = 6

const groundBody = new CANNON.Body({ type: CANNON.Body.KINEMATIC })
groundBody.addShape(new CANNON.Plane())
groundBody.position.set(0, -10, 0)
world.addBody(groundBody)

const prism = new THREE.Group()
const prismGeo = new THREE.CylinderGeometry(1.5, 1.5, 3.5, 3, 1)
const prismMat = new THREE.MeshStandardMaterial({
    metalness: 0.7,
    roughness: 0.05,
    emissive: 0x220022,
    emissiveIntensity: 0.6,
    envMapIntensity: 0.6,
    transparent: true,
    opacity: 0.98
})
const prismMesh = new THREE.Mesh(prismGeo, prismMat)
prismMesh.castShadow = true
prism.add(prismMesh)


const glowMat = new THREE.MeshBasicMaterial({
color: THEMES[themeIndex].colors[0],
transparent: true,
opacity: 0.9,
blending: THREE.AdditiveBlending
})

const prismEdges = new THREE.Mesh(new THREE.CylinderGeometry(1.51, 1.51, 3.6, 3, 1), glowMat)
prismEdges.scale.set(1.01, 1.01, 1.01)
prismEdges.material.side = THREE.DoubleSide
prism.add(prismEdges)


prism.position.set(0, 0.6, 0)
scene.add(prism)


function pulsePrism(intensity) {
const s = 1 + intensity * 0.6
prism.scale.lerp(new THREE.Vector3(s, s, s), 0.12)
prism.rotation.y += 0.006 + intensity * 0.05
}

const particleCount = 6000
const particlesGeo = new THREE.BufferGeometry()
const positions = new Float32Array(particleCount * 3)
const colors = new Float32Array(particleCount * 3)
const sizesArr = new Float32Array(particleCount)


for (let i = 0; i < particleCount; i++) {
    const i3 = i * 3
    const r = Math.pow(Math.random(), 0.8) * 40
    const angle = Math.random() * Math.PI * 4
    positions[i3 + 0] = Math.cos(angle) * r
    positions[i3 + 1] = (Math.random() - 0.5) * 6
    positions[i3 + 2] = Math.sin(angle) * r


    const col = new THREE.Color(THEMES[themeIndex].colors[i % THEMES[themeIndex].colors.length])
    colors[i3 + 0] = col.r
    colors[i3 + 1] = col.g
    colors[i3 + 2] = col.b


    sizesArr[i] = Math.random() * 0.8 + 0.2
}

particlesGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
particlesGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3))
particlesGeo.setAttribute('size', new THREE.BufferAttribute(sizesArr, 1))

const sprite = new THREE.TextureLoader().load('https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/sprites/circle.png')
const pointsMat = new THREE.PointsMaterial({
    size: 0.12,
    vertexColors: true,
    map: sprite,
    alphaTest: 0.01,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
})
const points = new THREE.Points(particlesGeo, pointsMat)
points.rotation.x = Math.PI * 0.02
scene.add(points)


const orbMeshes = []
const orbBodies = []
const orbCount = 10
for (let i = 0; i < orbCount; i++) {
    const orbMat = new THREE.MeshStandardMaterial({
    color: THEMES[themeIndex].colors[i % THEMES[themeIndex].colors.length],
    emissive: THEMES[themeIndex].colors[(i + 1) % THEMES[themeIndex].colors.length],
    emissiveIntensity: 0.6,
    metalness: 0.3,
    roughness: 0.1
})
const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.6, 24, 24), orbMat)
mesh.position.set((Math.random() - 0.5) * 12, Math.random() * 4 + 1, (Math.random() - 0.5) * 12)
scene.add(mesh)


const shape = new CANNON.Sphere(0.6)
const body = new CANNON.Body({ mass: 1, shape })
body.position.set(mesh.position.x, mesh.position.y + 4, mesh.position.z)
body.linearDamping = 0.9
world.addBody(body)


orbMeshes.push(mesh)
orbBodies.push(body)
}

//Audio
const listener = new THREE.AudioListener()
camera.add(listener)
const audio = new THREE.Audio(listener)
const audioLoader = new THREE.AudioLoader()

audioLoader.load('./public/music/music.mp3', (buffer) => {
audio.setBuffer(buffer)
audio.setLoop(true)
audio.setVolume(0.6)
})

const analyser = new THREE.AudioAnalyser(audio, 64)

playBtn.addEventListener('click', () => {
    if (!audio.isPlaying) audio.play(); else audio.pause();
})

fileInput.addEventListener('change', (e) => {
const file = e.target.files[0]
if (!file) return
    const url = URL.createObjectURL(file)
    audioLoader.load(url, (buffer) => {
    audio.setBuffer(buffer)
    audio.setLoop(true)
    audio.setVolume(0.7)
    audio.play()
})
})

const raycaster = new THREE.Raycaster()
const mouse = new THREE.Vector2()


window.addEventListener('click', (ev) => {
mouse.x = (ev.clientX / window.innerWidth) * 2 - 1
mouse.y = -(ev.clientY / window.innerHeight) * 2 + 1
raycaster.setFromCamera(mouse, camera)
const intersects = raycaster.intersectObjects([prismMesh, ...orbMeshes], true)

if (intersects.length) {

    themeIndex = (themeIndex + 1) % THEMES.length
    applyTheme(themeIndex)
    }
})

function applyTheme(idx) {
const theme = THEMES[idx]

const cAttr = particlesGeo.getAttribute('color')
for (let i = 0; i < particleCount; i++) {
    const col = new THREE.Color(theme.colors[i % theme.colors.length])
    const i3 = i * 3
    cAttr.array[i3 + 0] = col.r
    cAttr.array[i3 + 1] = col.g
    cAttr.array[i3 + 2] = col.b
}
cAttr.needsUpdate = true

orbMeshes.forEach((m, i) => {
const c = theme.colors[i % theme.colors.length]
m.material.color.setHex(c)
m.material.emissive.setHex(theme.colors[(i + 1) % theme.colors.length])
})

glowMat.color.setHex(theme.colors[0])
}

const clock = new THREE.Clock()
let lastTime = 0

function tick() {
const elapsed = clock.getElapsedTime()
const delta = elapsed - lastTime
lastTime = elapsed

let avg = 0
if (audio.isPlaying || analyser.getAverageFrequency()) {
    avg = analyser.getAverageFrequency() / 256 
}

points.rotation.y += 0.0012 + avg * 0.08
points.rotation.x += 0.0005
points.material.size = 0.08 + avg * 0.28

pulsePrism(avg)
prismMat.emissive.setHex(THEMES[themeIndex].colors[Math.floor((elapsed * 3) % THEMES[themeIndex].colors.length)])
prismEdges.material.color.setHex(THEMES[themeIndex].colors[Math.floor((elapsed * 2.2) % THEMES[themeIndex].colors.length)])

world.step(1 / 60, delta, 3)
for (let i = 0; i < orbMeshes.length; i++) {
    const m = orbMeshes[i]
    const b = orbBodies[i]
    m.position.copy(b.position)
    m.quaternion.copy(b.quaternion)


    const toCenter = new CANNON.Vec3().copy(new CANNON.Vec3().copy(new CANNON.Vec3(0, 1.8, 0)).vsub(b.position))
    toCenter.scale(0.3, toCenter)
    b.applyForce(toCenter, b.position)


    if (avg > 0.2) {
        const impulse = (Math.random() - 0.5) * avg * 50
        b.applyImpulse(new CANNON.Vec3(impulse, impulse * 0.6, impulse), b.position)
    }
}

camera.position.x = Math.sin(elapsed * 0.6) * 1.2 * (0.6 + avg)
camera.position.z = 18 - (avg * 8)
camera.lookAt(0, 1, 0)

controls.update()
renderer.render(scene, camera)
requestAnimationFrame(tick)
}

window.addEventListener('resize', () => {
sizes.width = window.innerWidth
sizes.height = window.innerHeight
camera.aspect = sizes.width / sizes.height
camera.updateProjectionMatrix()
renderer.setSize(sizes.width, sizes.height)
})

applyTheme(themeIndex)

tick()