import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';

const blocker = document.getElementById('blocker');
const instructions = document.getElementById('instructions');

// --- Scene Setup ---
const scene = new THREE.Scene();
const fogColor = 0x0a0a1a;
scene.background = new THREE.Color(fogColor);
scene.fog = new THREE.Fog(fogColor, 20, 100);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping; 
renderer.toneMappingExposure = 1;
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

// --- Player Controls 
const controls = new PointerLockControls(camera, document.body);
const playerHeight = 5; 
const crouchHeight = 4;
controls.getObject().position.y = playerHeight; 
scene.add(controls.getObject());

// locking/unlocking the cursor
instructions.addEventListener('click', () => controls.lock());
controls.addEventListener('lock', () => instructions.style.display = 'none');
controls.addEventListener('unlock', () => instructions.style.display = '');

// --- Keyboard Input 
const keyState = {};
document.addEventListener('keydown', (event) => keyState[event.code] = true);
document.addEventListener('keyup', (event) => keyState[event.code] = false);

// --- Lighting Setup 
const ambientLight = new THREE.AmbientLight(0xffffff, 0.03);
scene.add(ambientLight);

const lightConfigs = [
    { color: 0xff9900, intensity: 0.4, position: { x: 3.4, y: 4, z: 4.7 }, castShadow: true },
    { color: 0xff9900, intensity: .5, position: { x: -2.7, y: 4, z: -14.1 }, castShadow: true },
    { color: 0xff9900, intensity: .5, position: { x: -15.6, y: 4, z: 10.7 }, castShadow: true },
    { color: 0xff9900, intensity: .5, position: { x: -9, y: 4, z: 8.8 }, castShadow: true },
    { color: 0xff9900, intensity: .5, position: { x: -22, y: 4, z: -8.2 }, castShadow: true },
    { color: 0xff9900, intensity: .5, position: { x: -2.7, y: 4, z: 7 }, castShadow: true }
];
lightConfigs.forEach(config => {
    const pointLight = new THREE.PointLight(config.color, config.intensity, 100);
    pointLight.position.set(config.position.x, config.position.y, config.position.z);
    if (config.castShadow) {
        pointLight.castShadow = true;
        pointLight.shadow.mapSize.width = 1024;
        pointLight.shadow.mapSize.height = 1024;
    }
    scene.add(pointLight);
});

// --- 3D Model Loading 
const gltfLoader = new GLTFLoader();
gltfLoader.load('./stars.glb', (gltf) => scene.add(gltf.scene));
gltfLoader.load('./mini-garden.glb', (gltf) => {
    const gardenModel = gltf.scene;
    gardenModel.position.set(10, -0.67, 0);
    gardenModel.rotation.y = Math.PI / 10;
    gardenModel.scale.set(10, 10, 10);
    gardenModel.traverse((child) => {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });
    scene.add(gardenModel);
});
gltfLoader.load('./minecraft_chest.glb', (gltf) => {
    const chestModel = gltf.scene;
    chestModel.position.set(-8.8, 1.8, 10);
    chestModel.rotation.y = Math.PI / 10;
    chestModel.scale.set(0.008, 0.008, 0.008);
    chestModel.traverse((child) => {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });
    scene.add(chestModel);
});

// --- Camera and Render Loop ---
camera.position.set(-2, 4, 15);
camera.rotation.x = Math.PI / 200;

const clock = new THREE.Clock();

// --- Walkable Area boundaries ---
const gardenCenter = new THREE.Vector2(10, 0);
const walkRadius = 27;

// --- Define Movement Speeds ---
const walkSpeed = 10;
const crouchSpeed = 3;

function animate() {
    requestAnimationFrame(animate);
    const delta = clock.getDelta();

    if (controls.isLocked === true) {
        const player = controls.getObject();
        let currentMoveSpeed; 

        // movement direction
        let moveDirection = new THREE.Vector3();
        if (keyState['KeyW']) moveDirection.z -= 1;
        if (keyState['KeyS']) moveDirection.z += 1;
        if (keyState['KeyA']) moveDirection.x -= 1;
        if (keyState['KeyD']) moveDirection.x += 1;
        
        if(moveDirection.length() > 0) moveDirection.normalize();
        
        // --- CROUCHING AND SPEED LOGIC ---
        if (keyState['ShiftLeft']) {
            player.position.y = crouchHeight;
            currentMoveSpeed = crouchSpeed;
        } else {
            player.position.y = playerHeight;
            currentMoveSpeed = walkSpeed;
        }

        // Apply movement using the determined speed
        player.translateX(moveDirection.x * currentMoveSpeed * delta);
        player.translateZ(moveDirection.z * currentMoveSpeed * delta);

        // --- Simple Boundary Check ---
        const playerPosition2D = new THREE.Vector2(player.position.x, player.position.z);
        if (playerPosition2D.distanceTo(gardenCenter) > walkRadius) {
            const directionToCenter = new THREE.Vector2().subVectors(gardenCenter, playerPosition2D).normalize();
            player.position.x += directionToCenter.x * 0.1;
            player.position.z += directionToCenter.y * 0.1;
        }
    }

    renderer.render(scene, camera);
}

animate();

// --- Window Resize
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});